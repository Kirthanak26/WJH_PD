<?php
$mysql_host = "localhost";
$mysql_database ="CRUD";
$mysql_username = "kirthanak26";
$mysql_password = "Purple1!";
?>
